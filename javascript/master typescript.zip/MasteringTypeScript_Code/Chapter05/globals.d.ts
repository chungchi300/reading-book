declare var CONTACT_EMAIL_ARRAY: string [];

interface IContactData {
    DisplayText: string;
    Email: string;
}

declare var CONTACT_DATA : IContactData [];
