declare module MergedModule {
    function functionB();
}