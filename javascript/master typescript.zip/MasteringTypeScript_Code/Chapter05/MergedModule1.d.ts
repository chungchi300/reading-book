declare module MergedModule {
    function functionA();
}