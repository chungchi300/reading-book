// typings install dt~require --save --global

// require.config( {
//     // baseUrl: "."
// });

require(['main'], (main) => {
    console.log(`inside main`);
});