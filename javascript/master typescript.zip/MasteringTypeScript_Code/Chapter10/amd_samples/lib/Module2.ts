
export default class Module2Default {
    print() {
        console.log(`Module2Default.print()`);
    }
}