

describe('sanity test', () => {
    it('should pass', () => {
        expect(true).toBeTruthy();
    });

});