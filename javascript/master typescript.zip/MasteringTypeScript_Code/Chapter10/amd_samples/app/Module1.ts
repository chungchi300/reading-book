// export class Module1 {
//     print() {
//         console.log(`Module1.print() called`);
//     }
// }