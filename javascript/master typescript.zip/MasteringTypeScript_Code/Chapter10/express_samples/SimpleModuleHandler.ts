
export function processRequest(req, res) {
    console.log(`SimpleModuleHandler.processRequest`);
    res.send('Hello World');
};
