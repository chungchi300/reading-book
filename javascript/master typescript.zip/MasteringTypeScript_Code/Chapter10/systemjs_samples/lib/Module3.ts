export class Module3 {
    print() {
        console.log(`Module3.print()`);
    }
}