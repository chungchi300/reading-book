export class Module2 {
    print() {
        console.log(`Module2.print`);
    }
}