describe('SimpleTest2.ts : sanity test 2', () => {
    it('should pass', () => {
        expect(true).toBeTruthy();
    });

});