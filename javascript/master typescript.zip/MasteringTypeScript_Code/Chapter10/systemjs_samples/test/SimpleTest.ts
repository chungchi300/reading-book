

describe('SimpleTest.ts : sanity test', () => {
    it('should pass', () => {
        expect(true).toBeTruthy();
    });

});