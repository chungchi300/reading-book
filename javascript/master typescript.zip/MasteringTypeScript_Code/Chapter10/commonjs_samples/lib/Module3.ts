export class Module3 {
    print() {
        console.log(`Module3.print()`);
    }
}

var myVariable = "This is a variable.";

export { myVariable }