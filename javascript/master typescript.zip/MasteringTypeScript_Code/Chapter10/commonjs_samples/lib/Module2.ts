
export default class Module2Default {
    print() {
        console.log(`Module2Default.print()`);
    }
}

export class Module2NonDefault {
    print() {
        console.log(`Module2NonDefault.print()`);
    }
}