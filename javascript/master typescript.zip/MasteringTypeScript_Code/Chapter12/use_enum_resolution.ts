
// interface ISystemSettings {
// }

// interface IGMailService {
// }

// enum Interfaces {
//     ISystemSettings,
//     IGMailService
// }

// class ServiceLocatorTypes {
//     public static register(
//         interfaceName: Interfaces, instance: any) {}
//     public static resolve(
//         interfaceName: Interfaces) {}
// }

// ServiceLocatorTypes.register(Interfaces.ISystemSettings, {});
// ServiceLocatorTypes.resolve(Interfaces.ISystemSettings);


