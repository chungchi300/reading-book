export interface ISystemSettings {
    SmtpServerConnectionString: string;
    SmtpFromAddress: string;
}

export class IISystemSettings {}