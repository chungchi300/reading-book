window.onload = () => {
    console.log("hello vscode");

};
