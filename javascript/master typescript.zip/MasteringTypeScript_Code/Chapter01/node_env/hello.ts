console.log('hello TypeScript');
