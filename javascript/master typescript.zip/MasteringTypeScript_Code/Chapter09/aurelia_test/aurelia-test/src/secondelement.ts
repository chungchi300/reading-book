import {bindable} from 'aurelia-framework';

export class SeconDelement {
    @bindable firstName;
}