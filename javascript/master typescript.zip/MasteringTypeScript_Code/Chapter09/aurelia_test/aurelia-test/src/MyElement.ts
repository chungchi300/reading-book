import {bindable} from 'aurelia-framework';

export class MyElement {
    @bindable firstName : string;
    @bindable id: string;
}