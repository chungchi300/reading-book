import {bindable} from 'aurelia-framework';

export class ClickableItem {
    @bindable displayName: string;
    @bindable idValue: number;
}
