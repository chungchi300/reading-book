console.log(`hello app.js`);

$(document).ready( () => {
    $("#content").html(`<h3>Hello TypeScript`);
    }
);